package com.techm.taas.service.impl;


import com.techm.taas.repository.GenericRepository;
import com.techm.taas.service.BaseService;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


/**
 * Service实现类 - Service实现类基类
 */

public class BaseServiceImpl<T extends Serializable, PK extends Serializable> implements BaseService<T, PK> {

	GenericRepository< T > baseDao;
	 
	   @Autowired
	   public void setDao( GenericRepository< T > daoToSet ){
		   baseDao = daoToSet;
		   baseDao.setClazz( T );
	   }
	   
	

    public T get(PK id) {
        return baseDao.get(id);
    }

    public List<T> get(PK[] ids) {
        return baseDao.get(ids);
    }

    public T get(String propertyName, Object value) {
        return baseDao.get(propertyName, value);
    }

    public List<T> getList(String propertyName, Object value) {
        return baseDao.getList(propertyName, value);
    }

    public List<T> getAll() {
        return baseDao.getAll();
    }

    public Long getTotalCount() {
        return baseDao.getTotalCount();
    }

    public boolean isExist(String propertyName, Object value) {
        return baseDao.isExist(propertyName, value);
    }

    public PK save(T entity) {
    	if(baseDao!=null){
    		 return baseDao.save(entity);
    	}else{
    		System.out.println("注入失败");
    		return null;
    	}
       
    }

    public void update(T entity) {
        baseDao.update(entity);
    }

    public void delete(T entity) {
        baseDao.delete(entity);
    }

    public void delete(PK id) {
        baseDao.delete(id);
    }

    public void delete(PK[] ids) {
        baseDao.delete(ids);
    }



	@Override
	public void delete(PK id) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public T getTransactionally(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

}
