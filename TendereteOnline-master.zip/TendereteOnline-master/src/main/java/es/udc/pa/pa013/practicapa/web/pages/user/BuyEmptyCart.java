package es.udc.pa.pa013.practicapa.web.pages.user;

public class BuyEmptyCart {

}
