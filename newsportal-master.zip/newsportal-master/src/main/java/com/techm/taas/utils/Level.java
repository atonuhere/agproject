package com.techm.taas.utils;

/**
 * 客户成熟度 枚举类
 */
public enum Level {

    ONE,      //★
    TWO,    //★★
    THREE, //★★★
    FOUR,  //★★★★
    FIVE, //★★★★★

}
