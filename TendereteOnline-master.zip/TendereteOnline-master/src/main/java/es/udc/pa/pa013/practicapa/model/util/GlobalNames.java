package es.udc.pa.pa013.practicapa.model.util;

public class GlobalNames {

    public static final String SPRING_CONFIG_FILE =
        "classpath:/spring-config.xml";

    private GlobalNames () {}

}
