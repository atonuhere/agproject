package es.udc.pa.pa013.practicapa.test.util;

public final class GlobalNames {

    public static final String SPRING_CONFIG_TEST_FILE =
        "classpath:/spring-config-test.xml";

    private GlobalNames () {}

}
