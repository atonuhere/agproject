package com.techm.taas.service;

import com.techm.taas.entity.Comment;

/**
 * Provides comment-related operations
 * 
 * @author Oleg Filippov
 */
public interface CommentService extends BaseService<Comment, String> {

}
