package com.techm.taas.web;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.techm.taas.service.CategoryService;
import com.techm.taas.service.ArticleService;
import com.techm.taas.service.TagService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.techm.taas.entity.Article;
import com.techm.taas.exception.NotFoundException;
import com.techm.taas.web.constants.Common;
import com.techm.taas.web.constants.URL;
import com.techm.taas.web.constants.View;

/**
 * Controller for home-page and static pages (about, contacts)
 * 
 * @author Oleg Filippov
 */
@Controller
public class MainController {

	private ArticleService articleService;
	private CategoryService categoryService;
	private TagService tagService;

	/**
	 * Constructor autowiring needed services
	 */
	@Autowired
	public MainController(ArticleService articleService,
			CategoryService categoryService,
			TagService tagService) {
		this.articleService = articleService;
		this.categoryService = categoryService;
		this.tagService = tagService;
	}

	/**
	 * Home-page, get news on first page
	 */
	@RequestMapping(method = RequestMethod.GET, value = URL.HOME)
	public ModelAndView home(HttpSession session) {
		
		return homeModelAndView(1, session);
	}
	
	/**
	 * Home-page, get news on custom page
	 */
	@RequestMapping(method = RequestMethod.GET,value = URL.HOME_CUSTOM_PAGE)
	public ModelAndView home(@PathVariable("number") Integer pageNumber,
			HttpSession session) {

		if (pageNumber == 1) {
			return new ModelAndView("redirect:" + URL.HOME);
		}
		
		return homeModelAndView(pageNumber, session);
	}
	
	/**
	 * Fills ModelAndView with news data
	 */
	@SuppressWarnings("unchecked")
	private ModelAndView homeModelAndView(Integer pageNumber, HttpSession session) {
		List<Article> articlesByPage = null;
		if (pageNumber < 1) {
			throw new NotFoundException("Page < 1");
		}
		
		Map<String, Object> articlesData = articleService.getByPage(pageNumber, Common.ARTICLES_PER_PAGE);
		Integer pageCount = (Integer) articlesData.get("pageCount");
		
		if(articlesData!=null){
			
			articlesByPage = (List<Article>) articlesData.get("articlesByPage");
			
			if (session.getAttribute("categories") == null) {
				session.setAttribute("categories", categoryService.getAllTransactionally());
			}
			if (session.getAttribute("tags") == null) {
				session.setAttribute("tags", tagService.getAllTransactionally());
			}
		}
		return new ModelAndView(View.HOME)
				.addObject("pageCount", pageCount)
				.addObject("articlesByPage", articlesByPage)
				.addObject("currentPage", pageNumber)
				.addObject("requestUrl", URL.HOME);
	}
	
	/**
	 * About-page
	 */
	@RequestMapping(method = RequestMethod.GET, value = URL.ABOUT)
	public String aboutPage() {

		return View.ABOUT;
	}

	/**
	 * Contacts-page
	 */
	@RequestMapping(method = RequestMethod.GET, value = URL.CONTACTS)
	public String contactsPage() {

		return View.CONTACTS;
	}
}
