package es.udc.pa.pa013.practicapa.web.pages.admin;

public class NotAuthorized {

}
