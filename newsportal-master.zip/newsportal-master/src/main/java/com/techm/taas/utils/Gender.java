package com.techm.taas.utils;

/**
 * 性别 枚举类
 */
public enum Gender {
    MALE,   //男性
	FEMALE  //女性
}
