package es.udc.pa.pa013.practicapa.model.orderline;

import es.udc.pojo.modelutil.dao.GenericDao;

public interface OrderLineDao extends GenericDao<OrderLine, Long> {

}
