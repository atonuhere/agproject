-- -----------------------------------------------------
-- Create SCHEMA
-- -----------------------------------------------------
CREATE TABLE user ( `user_id` decimal(10) NOT NULL PRIMARY KEY, `login` varchar(255) , `password` varchar(255), `email` varchar(255), `name` varchar(255) );
CREATE TABLE role ( `role_id` decimal(10) NOT NULL PRIMARY KEY , `role` varchar(255) NOT NULL );
CREATE TABLE user_role ( `user_id` decimal(10) , `role_id` decimal(10));
CREATE TABLE category ( `category_id` decimal(10) NOT NULL PRIMARY KEY, `name` varchar(255));
CREATE TABLE article ( `article_id` decimal(10) NOT NULL PRIMARY KEY, `title` varchar(255), `preview` varchar(255), `content` varchar(255), `user_id` decimal(10), `category_id` decimal(10));
CREATE TABLE tag ( `tag_id` decimal(10) NOT NULL PRIMARY KEY , `name` varchar(255));
CREATE TABLE article_tag ( `article_id` decimal(10), `tag_id` decimal(10));
