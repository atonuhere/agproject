package es.udc.pa.pa013.practicapa.web.pages.user;


public class NotFound {
	
	private Long ID;

	public Long getID() {
		return ID;
	}

	public void setID(Long productId) {
		ID = productId;
	}

}
