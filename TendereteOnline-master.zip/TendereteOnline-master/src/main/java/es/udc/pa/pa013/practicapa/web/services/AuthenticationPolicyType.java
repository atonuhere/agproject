package es.udc.pa.pa013.practicapa.web.services;

public enum AuthenticationPolicyType {
	ALL_USERS, AUTHENTICATED_USERS, NON_AUTHENTICATED_USERS;
}
